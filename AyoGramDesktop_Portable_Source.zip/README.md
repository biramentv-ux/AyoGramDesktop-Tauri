# AyoGram Desktop Hybrid Application

This is a hybrid desktop application that combines features from AyoGram and exDekstop, designed to work as a standalone Windows client without requiring an Android emulator.

## Features

- Ghost Mode (скрит режим)
- Message history/anti-recall
- Filters
- Streamer mode
- Local Premium
- Translator
- Appearance customization
- Media preview

## Building

To build this application:

1. Make sure you have CMake and MinGW installed
2. Run the build script:
   ```
   build.bat
   ```

## Translation Support

The application currently supports Bulgarian language interface. Translations are managed through Qt translation system.

## Project Structure

- `main.cpp` - Main application entry point
- `mainwindow.h/cpp` - Main window implementation
- `translations/` - Translation files directory
- `CMakeLists.txt` - Build configuration
- `build.bat` - Windows build script

## License

This project is licensed under the MIT License - see the LICENSE file for details.