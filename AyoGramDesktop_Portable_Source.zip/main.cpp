#include "mainwindow.h"
#include <QApplication>
#include <QTranslator>
#include <QLocale>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    
    // Set application properties
    app.setApplicationName("AyoGram Desktop Hybrid");
    app.setApplicationVersion("1.0");
    app.setOrganizationName("AyuGram");
    app.setOrganizationDomain("ayugram.org");
    
    // Set up locale for Bulgarian language
    QLocale::setDefault(QLocale::Bulgarian);
    
    // Create and show main window
    MainWindow window;
    window.show();
    
    return app.exec();
}
